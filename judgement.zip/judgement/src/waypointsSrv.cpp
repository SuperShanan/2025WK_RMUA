#include <ros/ros.h>
#include "judgement/pathfuwu.h"
#include <geometry_msgs/Point.h>
// #include <fstream>
#include <string>
// #include <yaml-cpp/yaml.h>
#include <vector>
// #include <map>

bool pathServiceCallback(judgement::pathfuwu::Request& req, judgement::pathfuwu::Response& res) {
    std::vector<float> waypoints;
    int point_num = 5;
    std::string param_name_base = "path/" + std::to_string(req.path_id) + "/wp";
    bool success = true;
    for (int i = 0; i < point_num; i++)
    {
        std::string param_name = param_name_base + std::to_string(i);

        std::vector<float> point;
        if(ros::param::get(param_name,point))
        {
            waypoints.insert(waypoints.end(),point.begin(),point.end());
    
        }else{
            ROS_ERROR("failed to get path!!!!");
            success = false;
        }
    }
    res.waypoints = waypoints;
    return success;
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "waypointsSrv");
    ros::NodeHandle nh;

    // ros::ServiceServer service = nh.advertiseService("getwaypoints", load_config);

    ros::ServiceServer service = nh.advertiseService("topath", pathServiceCallback);
    ROS_INFO("Ready to receive requests.");
    ros::spin();

    return 0;
}