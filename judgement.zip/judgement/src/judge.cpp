#include <Eigen/Eigen>
#include <Eigen/Dense>
#include <algorithm>
#include <iostream>
#include <ros/ros.h>
#include <std_msgs/Float64.h>
#include <geometry_msgs/PoseStamped.h>
#include <vector>
#include <string>
// #include "judgement/pathfuwu.h"
#include "judgement/judge.h"

using namespace std;
//存放引导航点
vector<vector<Eigen::Vector3d>> list_original ;
vector<Eigen::Vector3d> wps;

// nav_msgs::Odometry odom;
geometry_msgs::PoseStamped odom;

ros::Publisher waypoint_pub;
ros::Timer timer_;

bool get_init = false;
bool get_end = false;
bool success_df = get_init && get_end;

double replan_distance = 5.0;
int circlecount = 0;

judge::judge(const ros::NodeHandle &nh, const ros::NodeHandle &nh_private)
    :nh_(nh), nh_private_(nh_private){
    odom_sub = nh.subscribe("/airsim_node/drone_1/debug/pose_gt", 10, odom_goal_cb);  

    init_pose_sub = nh.subscribe("/airsim_node/initial_pose",10,init_cb);
    end_pose_sub = nh.subscribe("/airsim_node/end_goal",10,end_cb);
    //get parameters from parameters server

}

bool getpathpoints(int path_id){

    int point_num = 5;//路径航点数量
    std::string param_name_base = "path/" + std::to_string(path_id) + "/wp/";

    for (int i = 0; i < point_num; i++)
    {
        std::string param_name = param_name_base + std::to_string(i);

        std::vector<float> point;
        if(ros::param::get(param_name,point))
        {
            // waypoints.insert(waypoints.end(),point.begin(),point.end());
            Eigen::Vector3d wp(point[0], point[1], point[2]);
            wps.push_back(wp);
            ROS_INFO("GET%f,%f,%f",point[0],point[1],point[2]);
        }else{
            ROS_ERROR("failed to get path!!!!");
            return false;
        }
    }
    return true;
}
//根据订阅起始点与终点查找路线
int findValueInVector(const std::vector<int>& vec, int valueToFind) 
{
    auto it = std::find(vec.begin(), vec.end(), valueToFind);
    if (it != vec.end()) {
        return std::distance(vec.begin(), it);
    }
    else {
        return -1;
    }
}    
void init_cb(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    if(get_init) return;
    else{
    //find
        init_num = findValueInVector(start_x,msg->pose.position.x);
        cout<<"init_num: "<<init_num<<endl; 
        //huoquhangdian
        get_init = true;
    }
}

void end_cb(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    if(get_end) return;
    else{
    //find
        end_num = findValueInVector(end_x,msg->pose.position.x);
        cout<<"end_num: "<<end_num<<endl;

        //huoquhangdian
        get_end = true;
        getpathpoints(init_num);
    }
}
//如果是用每次给点，判断位置函数
void getCircleCenter(const ros::TimerEvent &e)
{
    std::vector<Eigen::Vector3d> replan(2);   //重规划点位
    geometry_msgs::Pose tmp_pt;  
    
    replan[0][0] = odom.pose.position.x;    //自身位置
    replan[0][1] = odom.pose.position.y;
    replan[0][2] = odom.pose.position.z; 
    double distance = (replan[0] - wps[circlecount]).norm();   //`norm()`函数计算这个差异向量的大小，即为两个向量之间的距离，自身位置和预先点的距离
    cout<<"distance: "<<(int)distance<<endl;

    //到达范围，发送下一个模糊点
    if (distance < replan_distance){
        // cout<<"ENTER!"<<endl;

        // waypoint_pub.publish(point);
        circlecount++;
        cout<<"circlecount: "<<circlecount<<endl;

    }  
}

//订阅里程
void odom_goal_cb(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    odom = *msg;
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "judge");
    ros::NodeHandle nh("~");
    ros::Rate rate(10);

    // timer_ = nh.createTimer(ros::Duration(0.02), getCircleCenter);  //0.02s检查一下是否到达目标点，到达后更新目标点位

    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}