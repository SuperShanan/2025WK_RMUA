#ifndef JUDGE_H
#define JUDGE_H

#include <Eigen/Eigen>
#include <algorithm>
#include <iostream>
#include <ros/ros.h>
#include <std_msgs/Float64.h>
#include <vector>

using std::vector;
using namespace std;

class judge
{
private:
    ros::NodeHandle nh_;
    ros::NodeHandle nh_private_;
    vector<int> start_x =  {-1,0,143,547,1349,1176,783,2,713,1032,1327,676,264};//起点X取整
    vector<int> end_x =  {-1,-2,141,545,1351,1178,785,0,712,1033,1330,678,263};//终点X取整

    ros::Subscriber init_pose_sub;
    ros::Subscriber end_pose_sub;
    ros::Subscriber odom_sub;

    ros::Publisher waypoint_pub;

    int init_num = 0;
    int end_num = 0;

public:
    judge(const ros::NodeHandle &nh, const ros::NodeHandle &nh_private);
    ~judge();
        
    void init_pose_cbk(const geometry_msgs::PoseStamped::ConstPtr &msg);
    void end_pose_cbk(const geometry_msgs::PoseStamped::ConstPtr &msg);
};

#endif